const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const OUT = path.join(ROOT, 'dist');
const EXCLUDE = new Set(['dist', 'package.json', 'build.js', 'server.js', 'vercel.json', '.git', 'node_modules']);

function copyTree(src, dst, top = true) {
  fs.mkdirSync(dst, { recursive: true });
  for (const ent of fs.readdirSync(src, { withFileTypes: true })) {
    if (top && EXCLUDE.has(ent.name)) continue;
    const s = path.join(src, ent.name);
    const d = path.join(dst, ent.name);
    if (ent.isDirectory()) copyTree(s, d, false);
    else fs.copyFileSync(s, d);
  }
}

function safePath(p) {
  const decoded = decodeURIComponent(p || '/');
  const normalized = path.posix.normalize(decoded).replace(/^\/+/, '');
  if (normalized.startsWith('..')) throw new Error(`Unsafe public path: ${p}`);
  return normalized || 'index.html';
}

fs.rmSync(OUT, { recursive: true, force: true });
copyTree(ROOT, OUT, true);

const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'siteclone.manifest.json'), 'utf8'));
let aliases = 0;
for (const resource of Object.values(manifest.resources || {})) {
  if (!resource.localPath || !resource.publicPath) continue;
  const src = path.join(ROOT, resource.localPath);
  if (!fs.existsSync(src) || !fs.statSync(src).isFile()) continue;
  const u = new URL(resource.publicPath, 'http://local.invalid');
  let publicFile = safePath(u.pathname);
  if (u.pathname === '/') publicFile = 'index.html';
  const dst = path.join(OUT, publicFile);
  if (!fs.existsSync(dst)) {
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.copyFileSync(src, dst);
    aliases++;
  }
}

console.log(`Exact capture copied to dist with ${aliases} manifest aliases.`);
